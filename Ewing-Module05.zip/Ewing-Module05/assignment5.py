#-----------------Script Header -----------------#
#                                                #
# Title: assignment5.py                          #
# Dev: Sherrard Ewing                            #
# Date: October 31, 2016                         #
# Description: A simple to-do-list manager.      #
#    Assignment 5 for IT FDN 100A - Root, UW PCE #
# Changelog: 10/31/16 - ewingsw wrote first      #
#    version.                                    #
#                                                #
#------------------------------------------------#

# Including the original assignment desicription in block comments below:

'''
1.	Create a text file called Todo.txt using the following data:

    Clean House,low
    Pay Bills,high

2.	When the program starts, load each row of data from the ToDo.txt text file into a Python dictionary.

    Tip: You can use a for loop to read a single line of text from the file and then place the data into a new
    dictionary object.

3.	After you get a row of data stored in a Python dictionary, add the new “row” into a Python List object (now the
    data will be managed as a table or two-dimensional array).

4.	Display the contents of the List to the user.

5.	Allow the user to Add or Remove tasks from the list using numbered choices. Something like this would work:

    print ("Choose 1 to Add task")
    print ("Choose 2 to Remove task")
    print ("Choose 3 to Save all tasks to the Todo.txt file and exit!")

6.	Save the data from the table into the Todo.txt file when the program exits.
'''

# Code for Assignment 5:

#-- Data --#

# Load each row of data from Todo.txt into a Python dictionary

# After you get a row of data stored in a Python dictionary, add the new “row” in to a Python List object (now the data\
#  will be managed as a table or two-dimensional array)

objFileHandler = open("Todo.txt", "r+")
lstTbl = []

for line in objFileHandler:
    dctLine = {line}
    lstTbl.append(dctLine)
    strTask = str()
    strPriority = str()
    dct_new_row = {"task": strTask, "priority": strPriority}


#-- Processing --#

# Define functions based on user choices:

# Choice 1: User chooses to enter a new task, process data accordingly
def userChoice1():
    strTask = input("Please enter the name of a task: ")
    strPriority = input("Please enter the priority of the task (low,medium,high): ")
    dct_new_row = {"task": strTask, "priority": strPriority}
    lstTbl.append(dct_new_row)
    print(lstTbl)

# Choice 2: User chooses to remove a task, process data accordingly
def userChoice2():
    print("\n\nHere is your current task list:\n")
    print(lstTbl)
    removePrompt = input("What task would you like to remove? ")
    lstTbl.pop(int(removePrompt))
    print("\nYour value has been removed.  This is your new task list:\n\n")
    print(lstTbl)

# Choice 3: User chooses to exit the program, save or exit without saving based on user input
def userChoice3():
    savePrompt = input("\n\nWould you like to save before you exit? (y/n): ")
    if savePrompt == "y":
        print("Your changes have been saved in Todo.txt.\n\nGoodbye!")
        objFileHandler.write(str(lstTbl))
        objFileHandler.close()
    else:
        print("You are discarding your changes. Todo.txt will remain unchanged.\n\nGoodbye!")
        objFileHandler.close()

#-- Presentation --#

# Present user with introductions:

print("\n\nWelcome to To-do List Manager 1.0\n\
      \r\n---------------------------------\
      \n\r\nThis program will manage your to-do list in a file called Todo.txt\
      \n\nHere are the current tasks in your file:\n")

# Display the contents of the List to the user.  Present them with the ability to make choices afterward.

print(lstTbl)

# Initiate the while loop until the user chooses to exit

while(True):

    # Present user with choices

    print("\n\nWhat would you like to do?\
        \n1. Add a new task\
        \n2. Remove an existing task\
        \n3. Exit\n\n")

    intChoice = int(input("Please enter the number for one of the choices above: "))

    #If user choses to Enter new data to the file, run userChoice1(), and continue the while loop
    if intChoice == 1:
        userChoice1()
    #If user chooses to remove existing data from the file, run userChoice2() and continue the while loop
    elif intChoice == 2:
        userChoice2()
    #If user chooses to exit the program, run userChoice3() and then end the program
    elif intChoice == 3:
        userChoice3()
        break